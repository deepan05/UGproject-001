<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "water_supply";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
 {
  die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Seller list</title>
<div class="header">
  
<div class="header-left"><a href="dashboard.php"><img src="../images/back_button.png" style="width: 55px; height: 50px;border-radius: 68px;"></a></div>
<div class="header-right">
  <a href="dashboard.php"><img src="../images/home_1.png" style="width: 65px; height: 60px;border-radius: 68px;"></a>
  <a href="sellers_add.php"><img src="../images/home.png" style="width: 65px; height: 60px;border-radius: 58px;"></a>
  
</div> 
</div>
<style>
  body{
    background: linear-gradient(135deg, #71b7e6, #9b59b6);
    color: white;
    font-family: times new roam;
    font-weight: 700;
  }
/*.header-right{
  width: 10px;
  height: 10px;
  border-radius: 75%;
  float: right;
  align-items: center;
}*/
.header-left{
  float: left;
}
.header-right{
  float: right;
}
   button {
  background-color: orange; /* Green */
  border: none;
  color: white;
  font-family: times new roman;
  font-size: 40px;
  font-weight: 700;
  padding: 15px 30px;
  border-radius: 68px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
}

#customers {
  font-family: times new roman, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
.header-right {
  float: right;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: center;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #04AA6D;
  color: white;
}
#customers td {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: lightblue;
  color: black;
}
</style>
</head>
<body>
<center>
  <h1>Seller list </h1></center>


<table id="customers">
  <tr>
    <th>s.no</th>
    <th>Seller Name</th>
    <th>Seller Mobile</th>
    <th>Seller Mobile2</th>
    <th>Company Name</th>
    <th>Action</th>
  </tr><br><br>


  <?php
  $sql = "SELECT * FROM sellers";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  $i=1;
  while($row = $result->fetch_assoc()) {
  ?>
  <tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $row['seller_name']; ?></td>
    <td><?php echo $row['phone_number1']; ?></td>
    <td><?php echo $row['phone_number2']; ?></td>
    <td><?php echo $row['company_name']; ?></td>
    <td><a href="seller_edit.php?id=<?php echo $row['seller_id']; ?>">EDIT/DELETE<td>
  </tr>
  <?php
  $i++;
}
}
$conn->close();
  ?>



</table>

</body>
</html>


