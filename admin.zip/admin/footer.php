<link rel="stylesheet" type="text/css" href="footer_style.css">
<footer>
  <div class="row primary">
  <div class="column about">

  <h3>About Drink Water Daily</h3>

   <p>
     Drink Water Daily is an app which brings to you an innovative concept of water at your fingertips. Yes, you heard it right! No more stacking up of water jars, just go to the app and get your water jars, as and when required! Don’t want to use the app, no problem! You can also order on our website, in just a few clicks!
  </p>

  <div class="social">
    <i class="fa-brands fa-facebook-square"></i>
    <i class="fa-brands fa-instagram-square"></i>
    <i class="fa-brands fa-twitter-square"></i>
    <i class="fa-brands fa-youtube-square"></i>
    <i class="fa-brands fa-whatsapp-square"></i>
  </div>
</div>

<div class="column links">
<h3>Social Media Links</h3>

 <ul>

  <li>
   <a href="#fa-whatsapp-square">What's App</a>
  </li>
  <li>
   <a href="#fa-facebook-square">Facebook</a>
  </li>
  <li>
   <a href="#fa-instagram-square">Instagram</a>
  </li>
  <li>
   <a href="#fa-twitter-square">Twitter</a>
  </li>
  <li>
    <a href="#fa-youtube-square">YOU TUBE</a>
  </li>
 </ul>

</div>


<div class="column links">
  <h3>Short Links</h3>
   <ul>
    <li>
     <a href="#faq">F.A.Q</a>
    </li>
    <li>
     <a href="#cookies-policy">Cookies Policy</a>
    </li>
    <li>
    <a href="#terms-of-services">Terms Of Service</a>
    </li>
    <li>
    <a href="#support">Support</a>
    </li>
  </ul>
</div>

<div class="column subscribe">
 <h3>Newsletter</h3>
  <div>
   <input type="email" placeholder="Your email id here" />
   <button>Subscribe</button>
   

  </div>

</div>

</div>
<div class="app">
  <!-- <h4>dowl</h4> -->

</div>
<div class="row copyright">
  <!-- <div class="footer-menu">

  <a href="">Home</a>
  <a href="">About</a>
  <a href="">Contact</a>
  <a href="">Blog</a>
  <a href="">Social</a>

  </div> -->
   <p>Copyright &copy; 2022 Deepan Water supply</p>
</div>
</footer>