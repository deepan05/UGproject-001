<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "water_supply";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if($_SERVER["REQUEST_METHOD"] == "POST")
{

    $supply_person_name =$_POST['supply_person_name'];
    $supply_person_email =$_POST['supply_person_Email'];
    $phone_number_1 =$_POST['phone_number(1)'];
    $phone_number_2 =$_POST['phone_number(2)'];
    $user_name =$_POST['user_name'];
    $password =$_POST['password'];
    $licence_number =$_POST['licence_number'];
    $vechicle_name =$_POST['vechicle_name'];
    $referencer_name =$_POST['Referencer_name'];
    $Aadhar_photo =$_POST['Aadhar_photo'];
    $licence_photo=$_POST['licence_photo'];
    $photo=$_POST['photo'];
    $vechicle =$_POST['vechical'];
    $home_address =$_POST['home_address'];
    $Date_of_register =$_POST['Date_of_register'];
    $sql = "INSERT INTO `supply_persons` (`supply_persons_name`,`phone_number_1`,`phone_number_2`,`user_name`,`password`,`licence_number`,`vechicle_name`,`referencer_name`,`address`,`vechicle`,`date_of_register`,`supply_persons_email`) VALUES ('$supply_person_name','$phone_number_1','$phone_number_2','$user_name','$password','$licence_number','$vechicle_name','$referencer_name','$home_address','$vechicle','$Date_of_register','$supply_person_email')";

    if ($conn->query($sql) === TRUE) 
    {
     echo "New record created successfully";
     header('Location: supply.php');
    } 
    else 
   {
    echo "Error: " . $sql . "<br>" . $conn->error;
   }

}
    
?>