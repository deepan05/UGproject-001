<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <title>ordering</title>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <div class="header">
      <div class="header-left"><a href="../customer_dashboard.php"><img src="../images/back_button.png" style="width: 55px; height: 50px;border-radius: 68px;"></a></div>
      <div class="header-right">
        <a href="../customer_dashboard.php"><img src="../images/home_1.png" style="width: 65px; height: 60px;border-radius: 70px;"></a>
        <a href="contact.php"><img src="../images/contact_us.png" style="width: 90px; height: 60px;border-radius: 68px;"></a>
      </div> 
    </head>
<body>
  <div class="container"><!-- <br><br><br><br><br><br> -->
   <center><div class="title">Order placement</div></center>
    <div class="content">
      <form action="booking_save.php" method="POST">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Order ID</span>
            <input type="text"  name="Customer_id" id="Customer_id" placeholder="Enter your ID"  >
          </div>
          <div class="input-box">
            <span class="details">Customer Name</span>
            <input type="text" name="Customer_name" id="Customer_name" placeholder="Enter your username" >
          </div>
          <div class="input-box">
            <span class="details">Home address</span>
            <input type="text area" name="home_address" id="home_address" placeholder="Enter your home address" >
          </div>
          <div class="input-box">
            <span class="details">Phone Number</span>
            <input type="text" name="phone_number" id="phone_number"placeholder="Enter your number" >
          </div>
          <div class="input-box">
            <span class="details">sellect seller</span>
            <select id="seller_selection" name="seller_selection" required>
              <option value="select the seller">(select the seller)</option>
              <option value="perumal">perumal</option>
              <option value="govintha rajan">govintha rajan</option>
              <option value="kumaresan">kumaresan</option>
              <option value="hemanathan">hemanathan</option>
              <option value="rajan bhabu">rajan babu</option>
            </select>
          </div>
          <table id="sales">
            <tr>
              <th>tye of cans</th>
              <th>250mL</th>
              <th>500mL</th>
              <th>1L</th>
              <th>2L</th>
              <th>25L</th>
            </tr>
            <tr>
              <td>Rate</td>
              <td>10 Rs</td>
              <td>20 Rs</td>
              <td>40 Rs</td>
              <td>80 Rs</td>
              <td>150 Rs</td>
            </tr>
          <div class="input-box">
            <span class="details">select the can</span>
            <select id="can-selection" name="can_selection" required>
              <option value="">Choose a can from the List</option>
              <option value="250ml">250mL</option>
              <option value="500ml">500mL</option>
              <option value="1l">1L</option>
              <option value="2l">2L</option>
              <option value="25l">25L</option>
            </select>
          </div>
          <div class="input-box">
            <span class="details">count</span>
            <input type="text" name="count" id="count" placeholder="Enter number of cans" >
          </div>
          <div class="input-box"> 
            <span class="details">sellect timing to be delivered</span>
            <select id="time_selection" name="time_selection" required>
              <option value="select the seller">(select the time)</option>
              <option value="office">9:00 A.M-6:00 P.M</option>
              <option value="home">9:00 A.M- 9:00 P.M</option>
          </div>
          
          </table>
          <div class="input-box">
            <span class="details">Date to be delivery</span>
            <input type="date" name="Date_of_delivery" id="Date_of_register" >
          </div>
          <!-- <div class="input-box">
            <span class="details">Company name</span>
            <input type="text" name="Company_name" id="Company_name" placeholder="Enter your Company name" >
          </div>
           <div class="input-box">
            <span class="details">company registration number</span>
            <input type="text" name="company_registration_number" id="company_registration_number" placeholde="Enter your company reg number" >
          </div> -->
          <!-- <div class="input-box">
            <span class="details">Aadhar Photo:</span>
            <input type="file" name="Aadhar_Photo" id="Aadhar_Photo"value="upload" >
          </div> -->
          <!-- <div class="input-box">
            <span class="details">document(2)</span>
            <input type="file" name="document(2)" id="document(2)" value="upload" >
          </div> -->
          <!-- <div class="input-box">
            <span class="details">photo</span>
            <input type="file" name="photo" id="photo" value="upload" >
          </div> -->
          
        </div>
        <div class="button">
          <input type="submit" value="Book">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
<style type="text/css">
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: times new roman,sans-serif;
}
.header-left{
  float: left;
}
.header-right{
  float: right;
}
body{
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: left;
  /*padding: 20px;*/
  background: linear-gradient(135deg, #71b7e6, #9b59b6);
} 
.container{
  max-width: 500px;
  width: 100%;
  background-color: #fff;
  padding: 25px 30px;
  /*padding-top: 80px;*/
  border-radius: 5px;
  box-shadow: 0 5px 10px rgba(0,0,0,0.15);
}
.container .title{
  font-size: 25px;
  font-weight: 500;
  position: relative;
  text-decoration:underline red; /**/
}
.container .title::before{
  content: "";
  /*position: relative;*/
  left: 0;
  bottom: 0;
  height: 3px;
  width: 30px;
  border-radius: 5px;

  background: linear-gradient(135deg, #71b7e6, #9b59b6);
}
#sales {
  font-family: times new roman, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#sales td, #sales th {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: center;
}

#sales tr:nth-child(even){background-color: #f2f2f2;}

#sales tr:hover {background-color: #ddd;}

#sales th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #04AA6D;
  color: white;
}
# td {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: lightblue;
  color: white;
}
.content form .user-details{
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin: 20px 0 12px 0;
}
form .user-details .input-box{
  margin-bottom: 15px;
  width: calc(100% / 2 - 20px);
}
form .input-box span.details{
  display: block;
  font-weight: 500;
  margin-bottom: 5px;
}
.user-details .input-box input{
  height: 45px;
  width: 100%;
  outline: none;
  font-size: 16px;
  border-radius: 5px;
  padding-left: 15px;
  border: 1px solid #ccc;
  border-bottom-width: 2px;
  transition: all 0.3s ease;
}
.user-details .input-box input:focus,
.user-details .input-box input:valid{
  border-color: #9b59b6;
}
 form .vechical-details .vechical-title{
  font-size: 20px;
  font-weight: 500;
 }
 form .category{
   display: flex;
   width: 80%;
   margin: 14px 0 ;
   justify-content: space-between;
 }
 form .category label{
   display: flex;
   align-items: center;
   cursor: pointer;
 }
 form .category label .dot{
  height: 18px;
  width: 18px;
  border-radius: 50%;
  margin-right: 10px;
  background: #d9d9d9;
  border: 5px solid transparent;
  transition: all 0.3s ease;
}
 #dot-1:checked ~ .category label .one,
 #dot-2:checked ~ .category label .two,
 #dot-3:checked ~ .category label .three{
   background: #9b59b6;
   border-color: #d9d9d9;
 }
 form input[type="radio"]{
   display: none;
 }
 form .button{
   height: 45px;
   margin: 35px 0
 }
 form .button input{
   height: 100%;
   width: 100%;
   border-radius: 5px;
   border: none;
   color: #fff;
   font-size: 18px;
   font-weight: 500;
   letter-spacing: 1px;
   cursor: pointer;
   transition: all 0.3s ease;
   background: linear-gradient(135deg, #71b7e6, #9b59b6);
 }
 form .button input:hover{
  /* transform: scale(0.99); */
  background: linear-gradient(-135deg, #71b7e6, #9b59b6);
  }
 @media(max-width: 584px){
 .container{
  max-width: 100%;
}
form .user-details .input-box{
    margin-bottom: 15px;
    width: 100%;
  }
  form .category{
    width: 100%;
  }
  .content form .user-details{
    max-height: 300px;
    overflow-y: scroll;
  }
  .user-details::-webkit-scrollbar{
    width: 5px;
  }
  }
  @media(max-width: 459px){
  .container .content .category{
    flex-direction: column;
  }
}

</style>