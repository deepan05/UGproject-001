<?php
// include("config/config.php");
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "water_supply";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// echo $t;
// exit;
if($_SERVER["REQUEST_METHOD"] == "POST")
{

    $seller_name =$_POST['seller_name'];
    $Seller_Email =$_POST['Seller_Email'];
    $phone_number_1 =$_POST['phone_number(1)'];
    $phone_number_2 =$_POST['phone_number(2)'];
    $user_name =$_POST['user_name'];
    $password =$_POST['password'];
    $GST_number =$_POST['GST_number'];
    $Company_name =$_POST['Company_name'];
    $company_registration_number =$_POST['company_registration_number'];
    // $document_2 =$_POST['document(2)'];
    $photo=$_POST['photo'];
    $vechicle =$_POST['vechicle'];
    $Address_of_company =$_POST['Address_of_company'];
    $Date_of_register =$_POST['Date_of_register'];
    // $document_1 =$_POST['document(1)'];

$sql = "INSERT INTO `sellers` (`Seller_name`,`user_name`,`password`,`seller_email`,`company_name`,`phone_number1`,`phone_number2`,`GST number`,`company_registration_number`,`vechicle`,`Address_of_company`,`Date_of_register`) VALUES ('$seller_name','$user_name','$password','$Seller_Email','$Company_name','$phone_number_1','$phone_number_2','$GST_number','$company_registration_number','$vechicle','$Address_of_company','$Date_of_register')";

if ($conn->query($sql) === TRUE) 
{
  echo "New record created successfully";
  header('Location: sellers.php');

} 
else 
{
  echo "Error: " . $sql . "<br>" . $conn->error;
}

}
?>