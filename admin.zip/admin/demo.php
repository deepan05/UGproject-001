<?php
$conn=mysql_connect("localhost","root","","water_supply")
$sql="SELECT * FROM supply_persons";
$result=$conn->query($sql);
if ($result->num_row>0) {
	while ($row=$result->fetch_assoc()) {
		echo "<tr><td>".row["id"]."</td><td>".row["supply_persons_name"]."</td><td>".row["phone_number_1,phone_number_2"],"</td>"
	}
	else{
		echo "No result";
	}
	$conn->close();
}
?>