<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "water_supply";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
 {
  die("Connection failed: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>supply person list</title>
  <div class="header-right"><a href="supply_add.php"><button>ADD</button></a></div>
<style>
  body{
    background: linear-gradient(135deg, #71b7e6, #9b59b6);
    color: white;
    font-family: times new roam;
    font-weight: 700;
  }

.header-right {
  float: right;
}
   button {
  background-color: orange; /* Green */
  border: none;
  color: white;
  padding: 15px 30px;
  border-radius: 8px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
}

#customers {
  font-family: times new roman, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: center;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #04AA6D;
  color: white;
}
#customers td {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: lightblue;
  color: white;
}

</style>
</head>
<body>

<center><h1>Supply person</h1></center>




<table id="customers">
  <tr>
    <th>s.no</th>
    <th>supply person Name</th>
    <th>phone number</th>
    <th>phone number2</th>
    <th>Date of register</th>
    <th>action</th>
  </tr>
  <!-- <a href="demo2.php"></a> -->
 <?php
  $sql = "SELECT * FROM supply_persons ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  $i=1;
  while($row = $result->fetch_assoc()) {
  ?>
  <tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $row['supply_persons_name']; ?></td>
    <td><?php echo $row['phone_number_1']; ?></td>
    <td><?php echo $row['phone_number_2']; ?></td>
    <td><?php echo $row['date_of_register']; ?></td>
    <td><a href="supply_person_edit.php">EDIT/DELETE</a></td>
  </tr>
  <?php
  $i++;
}
}
$conn->close();
  ?>
  
</table>

</body>
</html>


