<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "water_supply";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
 {
  die("Connection failed: " . $conn->connect_error);
}
?>
<title>Admin dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="dashboard_content.css">
<style type="text/css">
  body {font-family: times new roman, sans-serif;}
  .mySlides {
    display: none;
  }
  img {vertical-align: middle;}
  .slideshow-container {
  /*max-width: 400px;*/
  height: 100px;
  /*position: absolute;*/
  margin-right: 150px;
  margin-left: 50px;
  }
  /*.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}*/

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
}
</style>
<div class="container">

  <!-- <h2>CUSTOMER:</h2> -->
   <ul class="responsive-table">
    <li class="table-header">
      <div class="col col-1">S.NO</div>
      <div class="col col-2">User type</div>
      
      <div class="col col-4">Actions</div>
      <!-- <div class="col col-5">5</div> -->
    </li>
    <li class="table-row">
      <div class="col col-1" data-label="No">1</div>
      <div class="col col-2" data-label="Customer Name">SELLERS (<?php
        $con = mysqli_connect("localhost","root","","water_supply");
        $sql = "SELECT * FROM sellers";
        $result = $conn->query($sql);
      if ($result = mysqli_query($con, $sql)) {

          // Return the number of rows in result set
          $rowcount = mysqli_num_rows( $result );
          
          // Display result
          printf( $rowcount);
       }
    ?>)</div>
      <!-- <div class="col col-3" data-label="address">xxxxy</div> -->
      <a href="seller_list.php"><div class="col col-4" data-label="active/deactive"><button>MANAGE  </button></div></a>
    </li>
    <li class="table-row">
      <div class="col col-1" data-label="No">2</div>
      <div class="col col-2" data-label="Customer Name">CUSTOMERS(<?php
        $con = mysqli_connect("localhost","root","","water_supply");
        $sql = "SELECT * FROM customers";
        $result = $conn->query($sql);
      if ($result = mysqli_query($con, $sql)) {

          // Return the number of rows in result set
          $rowcount = mysqli_num_rows( $result );
          
          // Display result
          printf( $rowcount);
       }
    ?>)</div>
      <!-- <div class="col col-3" data-label="address">asfsfegergerhej</div> -->
      <a href="Customer_list.php"><div class="col col-4" data-label="active/deactive"><button>MANAGE  </button></div></a>
    </li>
    <li class="table-row">
      <div class="col col-1" data-label="No">3</div>
      <div class="col col-2" data-label="Customer Name">DELIVERY PERSONS(<?php
        $con = mysqli_connect("localhost","root","","water_supply");
        $sql = "SELECT * FROM supply_persons";
        $result = $conn->query($sql);
      if ($result = mysqli_query($con, $sql)) {

          // Return the number of rows in result set
          $rowcount = mysqli_num_rows( $result );
          
          // Display result
          printf( $rowcount);
       }
    ?>)</div>
      <!-- <div class="col col-3" data-label="address">csdvdgsfvweg</div> -->
      <a href="supply_list.php"><div class="col col-4" data-label="active/deactive"><button>MANAGE  </button></div></a>
    </li>
    <li class="table-row">
      <div class="col col-1" data-label="No">4</div>
      <div class="col col-2" data-label="Customer Name">BOOKINGS</div>
      <!-- <div class="col col-3" data-label="address">-----</div> -->
      <a href="booking_list.php"><div class="col col-4" data-label="active/deactive"><button>MANAGE  </button></div></a>
    </li>
  </ul>

</div>
<div class="content-left">
  <div class="mySlides fade">
  <!-- <div class="numbertext">1 / 5</div> -->
  <img src="../images/s1.jpeg" style="width:100%">
  <!-- <div class="text">Caption Text</div> -->
</div>

<div class="mySlides fade">
  <!-- <div class="numbertext">2 / 5</div> -->
  <img src="../images/s2.jpeg" style="width:100%">
  <!-- <div class="text">Caption Two</div> -->
</div>

<div class="mySlides fade">
  <!-- <div class="numbertext">3 / 5</div> -->
  <img src="../images/s3.png" style="width:100%">
  <!-- <div class="text">Caption Three</div> -->
</div>
<div class="mySlides fade">
  <!-- <div class="numbertext">4 / 5</div> -->
  <img src="../images/new_login_bg2.jpeg" style="width:100%">
  <!-- <div class="text">Caption Three</div> -->
</div>
<!-- <div class="content-left">
  <div class="mySlides fade">
  <div class="numbertext">5 / 5</div>
  <img src="../images/tap1.jpeg" style="width:100%">
  <div class="text">Caption Text</div>
</div> -->
<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <!-- <span class="dot"></span> -->

</div>
<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>


</div>