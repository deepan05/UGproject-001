<link rel="stylesheet" type="text/css" href="../css/header_style.css">

<div class="header">
  <a href="#default" class="logo">
<img src="images/Logo.png" width="56" ></a>
  <div class="header-right">
    <a class="active" href="index1.php">Home</a>
    <a href="./contact.php">Contact</a>
    <a href="about_water_supply.php">About</a>
    <a class="deepan" href="login.php" >LOGOUT</a>
  </div>
</div>