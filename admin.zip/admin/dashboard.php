<?php
session_start();
//print_r($_SESSION);
//echo "test";
include('dashboard_header.php');
include('dashboard_content.php');
// include('footer.php');
?>