<link rel="stylesheet" type="text/css" href="booking_dashboard.css">
<body>
  <form action="" method="post">
 <div><br><br><br>
  <div class=".container">
  <div class="title"><center>Water can Booking</center></div>
  <div class="elem-group">
    <label for="name">Coustomer Name</label>
    <input type="text" id="costomer_name" name="costomer_name" placeholder="Enter your name" pattern=[A-Z\sa-z]{3,20} required>
  </div>
  <div class="elem-group">
    <label for="email">Coustomer E-mail</label>
    <input type="email" id="costomer_email" name="costomer_email" placeholder="Enter your E-mail" required>
  </div>
  <div class="elem-group">
    <label for="phone">coustomer Phone</label>
    <input type="tel" id="costomer_phone" name="costomer_phone" placeholder="Enter your phone number" pattern=(\d{3})-?\s?(\d{3})-?\s?(\d{4}) maxlength="10" required>
  </div>
  <hr>
  <!-- <div class="elem-group inlined">
    <label for="adult">Adults</label>
    <input type="number" id="adult" name="total_adults" placeholder="2" min="1" required>
  </div> -->
  <div class="elem-group inlined">
    <label for="child">Number of cans You need:</label>
    <input type="number" id="number of cans" name="number of cans" placeholder="enter number of can you need" min="0" required>
  </div>
  <div class="elem-group inlined">
    <label for="checkin-date">Order-date:</label>
    <input type="date" id="ordered-date" name="ordered-date" required>
  </div>
  <!-- <div class="elem-group inlined">
    <label for="checkout-date">Delivery-Date:</label>
    <input type="date" id="delivery-date" name="delivery-Date" required>
  </div><br><br> -->
  <div class="elem-group">
    <label for="can-selection">Select can Preference</label>
    <select id="can-selection" name="can_selection" required>
        <option value="">Choose a can from the List</option>
        <option value="250ml">250mL</option>
        <option value="500ml">500mL</option>
        <option value="1l">1L</option>
        <option value="2l">2L</option>
        <option value="25l">25L</option>
    </select>
  </div>
  <hr>
  <div class="elem-group">
    <label for="message">Anything Else?</label>
    <textarea id="message" name="visitor_message" placeholder="Tell us anything else that might be important." required></textarea>
  </div>
  <button type="submit">Book It</button>
</div>
</div>
</form>
</body>