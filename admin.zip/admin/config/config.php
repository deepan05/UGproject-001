<?php
// echo $t=1;
   $db = mysqli_connect('localhost','root','','water_supply');
?>