<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
$username =$_POST['user_name'];
$password=$_POST['pswrd'];
date_default_timezone_set("Asia/Kolkata");
// echo "The time is " . date("h:i:sa");
// exit();
// $cookie_value = $cookie_name;
// setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
}
?> 
<html>
<body>

 <?php
if ( $username=="admin") {
    // echo "The time is " . date("h:i:sa");
   echo"ok";
} else {
    echo "not";
    // header("location:dummy.php");
    }
?>

</body>
</html>
