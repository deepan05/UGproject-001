<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "water_supply";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if($_SERVER["REQUEST_METHOD"] == "POST")
{
  $customer_name =$_POST['Customer_name'];
  $seller_type   =$_POST['seller_selection'];
  $cans_type  =$_POST['can_selection'];
  $count =$_POST['count'];
  $Delivery_time =$_POST['time_selection'];
  $Date  =$_POST['Date_of_delivery'];
  $customer_address =$_POST['home_address'];
  $phone_number=$_POST['phone_number'];
}
$sql = "INSERT INTO `booking` (`Customer_name`,`seller_type`,`cans_type`,`count`,`Delivery_time`,`Date`,`customer_address`,`phone_number`) VALUES ('$customer_name','$seller_type','$cans_type','$count',' $Delivery_time','$Date','$customer_address','$phone_number')";

if ($conn->query($sql) === TRUE) 
{
  echo "New record created successfully";
} 
else 
{
  echo "Error: " . $sql . "<br>" . $conn->error;
}
?>