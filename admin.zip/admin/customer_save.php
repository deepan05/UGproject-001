<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "water_supply";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if($_SERVER["REQUEST_METHOD"] == "POST")
{
  $customer_name =$_POST['Customer_name'];
  $customer_email =$_POST['Customer_email'];
  $phone_number_1 =$_POST['phone_number(1)'];
  $phone_number_2 =$_POST['phone_number(2)'];
  $user_name =$_POST['user_name'];
  $password =$_POST['password'];
  $Aadhar_number =$_POST['Aadhar_number'];
  $Aadhar_Photo =$_POST['Aadhar_Photo'];
  $photo =$_POST['photo'];
  $home_address =$_POST['home_address'];
  $gender =$_POST['Gender'];
  $Date_of_register =$_POST['Date_of_register'];
}
$sql = "INSERT INTO `customers` (`costomer_name`,`costomer_email`,`phone_number_1`,`phone_number_2`,`user_name`,`password`,`aadhar_number`,`home_address`,`gender`,`date_of_register`)VALUES ('$customer_name','$customer_email','$phone_number_1','$phone_number_2',' $user_name','$password','$Aadhar_number','$home_address','$gender','$Date_of_register')";

if ($conn->query($sql) === TRUE) 
{
  echo "New record created successfully";
} 
else 
{
  echo "Error: " . $sql . "<br>" . $conn->error;
}
?>