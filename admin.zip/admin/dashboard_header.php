<link rel="stylesheet" type="text/css" href="dashboard_header_style.css">

<div class="header">
  <a href="#default" class="logo">
<img src="../images/Logo.png" style="width: 56px; height: 51px;border-radius: 70px;"></a>
  <div class="header-right">
    <a class="active" href="../index1.php">Home</a>
    <a href="../contact.php">Contact</a>
    <!-- <a href="about_water_supply.php">About</a> -->
    <a class="deepan" href="logout.php" >logout</a>
  </div>
</div>    

  <!-- <div class="banner">
    <img src="images/bg.jpg">
  <center><h1>MINERAL WATER SUPPLY</h1></center> 
  <p>Resize the browser window to see the effect.</p>
  <p>Some content..</p> 
 
</div> -->
  
  

