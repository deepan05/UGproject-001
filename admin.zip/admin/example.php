<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $myseller_ID =($db,$_POST['seller_id']);
    $myseller_name =($db,$_POST['seller_name']);
    $myseller_email =($db,$_POST['seller_Email']);
    $myphone_number_1 =($db,$_POST['phone_number(1)']);
    $myphone_number_2 =($db,$_POST['phone_number(2)']);
	$myuser_name =($_POST['user_name']);
    $mypassword = ($_POST['password']);
    $myGST_number = ($_POST['GST_number']);
    $myCompany_name =($db,$_POST['Company_name']);
    $mycompany_registration_number =($db,$_POST['company_registration_number']); 
	$mydocument_1 =($_POST['document(1)']);
    $mydocument_2 = ($_POST['document(2)']);
    $myphoto =($_POST['photo']);
    $myAddress_of_company = ($_POST['Address_of_company']);
    $myvechicle_details = ($_POST['vechicle']);
    $myDate_of_register =($_POST['Date_of_register']);
     
     $db = mysqli_connect('localhost','root','','water_supply/seller');
    //  $conn = new mysqli($servername, 
    // $username, $password, $dbname);
     if ($conn->connect_error) {
    die("Connection failed:".$conn->connect_error);
         } 
  
$sqlquery = "INSERT INTO table VALUES 
    ($myseller_id,$myseller_name,$seller_email,$myphone_number_1,$myphone_number_2,$myuser_name,$mypassword,$myGST_number,$mycompany_name,$mycompany_registration_number,$mydocument_1,$mydocument_2,$myphoto,$myAdderss_of_company,$myvechicle_detail,$mydate_of_register)"
  
if ($conn->query($sql) === TRUE) {
    echo "record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
?>